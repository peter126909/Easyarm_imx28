/*
 * Copyright (C) 2016, Bin Meng <bmeng.cn@gmail.com>
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __FSP_VPD_H__
#define __FSP_VPD_H__

/* IvyBridge FSP does not support VPD/UPD */

#endif

/*
 * SPDX-License-Identifier:	GPL-2.0+
 */

#include <generated/asm-offsets.h>

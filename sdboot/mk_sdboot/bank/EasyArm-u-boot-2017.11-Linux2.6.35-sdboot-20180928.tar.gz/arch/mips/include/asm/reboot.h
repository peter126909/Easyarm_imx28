/*
 * Copyright (C) 1997, 1999, 2001, 06 by Ralf Baechle
 * Copyright (C) 2001 MIPS Technologies, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0
 */
#ifndef _ASM_REBOOT_H
#define _ASM_REBOOT_H

extern void _machine_restart(void);

#endif /* _ASM_REBOOT_H */

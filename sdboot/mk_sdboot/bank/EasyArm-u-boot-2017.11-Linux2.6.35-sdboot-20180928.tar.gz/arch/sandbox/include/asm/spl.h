/*
 * Copyright (c) 2016 Google, Inc
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __asm_spl_h
#define __asm_spl_h

#define CONFIG_SPL_BOARD_LOAD_IMAGE

enum {
	BOOT_DEVICE_BOARD,
};

#endif
